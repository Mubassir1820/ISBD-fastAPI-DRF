def my_sum(a, b, c=0, d=0, e=0):
    return a + b + c + d + e


my_sum(3, 5)
my_sum(30, 40)


my_sum(1, 2, 3)
my_sum(4, 5, 6)


my_sum(1, 2, 3, 4)

my_sum(1, 2, 3, 4, 5)
