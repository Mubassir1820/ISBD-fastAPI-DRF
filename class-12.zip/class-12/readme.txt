[*] postional argument , keyword argument
[*] *args , **kwargs
[*] variable scope
[*] List sorting
[*] Dynamic access of a list from a function