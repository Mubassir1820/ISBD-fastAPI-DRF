def some(a, *args):
    print(a)
    print(args)


some(1)
some(1, 2, 3)
