def some(*args, **kwargs):
    print(args)
    print(kwargs)


some(1, 2, 3, username="akb", email="abc")
