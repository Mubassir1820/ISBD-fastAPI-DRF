ls = [10, 1, 25, 75, 30, 15]


ite = reversed(ls)
rev_ls = list(ite)
print(rev_ls)
