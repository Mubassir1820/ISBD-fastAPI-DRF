ls = [10, 1, 25, 75, 30, 15]

# Sort
# Ascending Order (from smaller to larger)
# Descending Order (from larger to smaller)

# Soting a list

# never manupulate original list
print(sorted(ls))

print(ls)

ls = sorted(ls)
print(ls)
