def my_sum(a, b):
    return a + b


def my_sum2(a, b, c):
    return a + b + c


def my_sum3(a, b, c, d):
    return a + b + c + d


my_sum(3, 5)
my_sum(30, 40)


my_sum2(1, 2, 3)
my_sum2(4, 5, 6)


my_sum3(1, 2, 3, 4)
