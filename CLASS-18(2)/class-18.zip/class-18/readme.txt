[*] module & package


3 types of module & package
- user define [covered]
- builtin [not covered]
- 3rd party [not covered]