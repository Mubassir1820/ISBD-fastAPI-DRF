# import <module_name>
import mock_2

ls1 = [1, 2, '3', 4, 5]
ls2 = [3,5]
ls3 = None

print(mock_2.analysis_ratings(ls2))