def divide_numbers(a: int, b: int) -> int:
    if b == 0:
        return 0
    return a / b