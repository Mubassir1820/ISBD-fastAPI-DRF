# import <module_name> as <alias>
import mock_2 as helper


mock_2 = "demo"
ls1 = [1, 2, '3', 4, 5]
ls2 = [3,5]
ls3 = None

print(helper.analysis_ratings(ls2))

print(helper.PI)