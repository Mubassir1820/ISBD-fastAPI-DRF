from calculator import (
    add_numbers,
    multiply_numbers,
    subtract_numbers,
    divide_numbers
)

result = add_numbers(a=1, b=2)
print(result)


result = subtract_numbers(a=1, b=2)
print(result)

result = multiply_numbers(a=1, b=2)
print(result)


result = divide_numbers(a=1, b=2)
print(result)

