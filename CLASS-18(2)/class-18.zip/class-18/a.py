from b import b
a = 10 

