from calculator.add import add_numbers
from calculator.sub import subtract_numbers
from calculator.mul import multiply_numbers
from calculator.div import divide_numbers


result = add_numbers(a=1, b=2)
print(result)


result = subtract_numbers(a=1, b=2)
print(result)

result = multiply_numbers(a=1, b=2)
print(result)


result = divide_numbers(a=1, b=2)
print(result)

