from a import a

b = 20