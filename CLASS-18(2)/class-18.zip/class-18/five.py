from calculator import (
    add, 
    sub,
    mul, 
    div
)

result = add.add_numbers(a=1, b=2)
print(result)


result = sub.subtract_numbers(a=1, b=2)
print(result)

result = mul.multiply_numbers(a=1, b=2)
print(result)


result = div.divide_numbers(a=1, b=2)
print(result)