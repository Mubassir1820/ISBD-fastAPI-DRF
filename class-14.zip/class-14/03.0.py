def calculate(base_number , power):
    return base_number ** power

# Square
calculate(5, 2)
calculate(10 , 2)
calculate(25, 2)


# Cube
calculate(40 , 3)
calculate(75 , 3)
calculate(100 , 3)


# quad
calculate(20 , 4)