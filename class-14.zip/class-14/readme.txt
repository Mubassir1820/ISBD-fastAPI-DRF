[*] functools (singledispatch , wraps , partial , lru_cache)
[*] Type hint / type annotation