def greet():
    # function body
    print("hello")


# function call
greet()
