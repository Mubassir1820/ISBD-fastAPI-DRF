1. Function Definition , Doc string
2. Return statement
3. Parameter & Argument , Multiple Parameter
4. Default Parameter (Optional Parameter)
5. Multiple Return
