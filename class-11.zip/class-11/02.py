def greet():
    """A function that simply print hello"""
    print("hello")


greet()
