# function input / parameter
def greet(name):

    print(f"hello {name}")


# function call with input (approach - 1) # better
greet(name="nahid")  # argument


# function call with input (approach - 2)
greet("shakib")
