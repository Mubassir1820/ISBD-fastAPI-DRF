def calculate(number):
    return number**2, number**3


result_square, result_cube = calculate(number=10)

print(result_square)
print(result_cube)
