[*] Lambda
[*] Lambda with sorted
[*] Higher order Function (function assignment, function as a argument)
[*] Closure (function returning function)
[*] decorator