# lambda function

# syntax -> lambda (paramaters) : returning value

def my_square(n):
    return n**2


fun = lambda n : n**2

print(fun(4))
print(fun(5))