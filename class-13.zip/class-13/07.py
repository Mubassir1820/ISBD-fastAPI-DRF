def some(n):
    sum = 0
    for i in range(1,n+1):
        sum += i
    
    return sum


print("Calling the function")
some(5)
print("Function called finish")


print("Calling the function")
some(10)
print("Function called finish")


print("Calling the function")
some(20)
print("Function called finish")


print("Calling the function")
some(30)
print("Function called finish")
