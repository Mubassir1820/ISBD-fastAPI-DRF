def some():
    print("hello")

# Function assign to another variable
another_fun = some


another_fun()
another_fun()
another_fun()
some()
another_fun()
another_fun()