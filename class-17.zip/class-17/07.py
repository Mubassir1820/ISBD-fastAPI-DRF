dc1 = {
    "name" : "salman",
    "age" : 10
}


print(list(dc1.keys()))
print(list(dc1.values()))


print('age' in dc1)