List
    unpack(*)

Dictionary
    get(key, default_value)
    keys()
    values()
    items()
    update(dictionary)
    setdefault(key, default_value)
    pop(key, default_value)
    clear()
    unpack(**)
    
    
    del
