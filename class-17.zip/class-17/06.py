dc1 = {
    "name" : "salman",
    "age" : 10
}

# print(dc1["email"])

print(dc1.get('email', 'example.com'))