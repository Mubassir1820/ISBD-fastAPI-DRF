# primitive data type (int, float, string)
a = 10
b = a

b = 20


print(a)
print(b)