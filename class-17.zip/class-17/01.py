# Referential Data type (List & Dictionary)
ls1 = [1,2,3]
ls2 = ls1

ls2[0] = 1000


ls3 = ls2 

ls3[-1] = 2000


print(ls1)
print(ls2)
print(ls3)
