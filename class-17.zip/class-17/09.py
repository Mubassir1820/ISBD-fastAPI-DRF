# update

person = {
    "name" : "salman",
    "age" : 10,
    "email" : "example.com"
}

extras = {
    "bio" : "CEO of innovative Skills",
    "expertise" : "ML / DL / AI",
    "email" : "yahoo.com"
}


person.update(extras)

print(person)
