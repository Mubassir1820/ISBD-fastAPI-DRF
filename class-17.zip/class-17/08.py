dc1 = {
    "name" : "salman",
    "age" : 10,
    "email" : "example.com"
}


# print(dc1.items())

# for item in dc1.items():
#     print(item)


for key, value in dc1.items():
    print(key , value) 


