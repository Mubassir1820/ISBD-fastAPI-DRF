person = {
    'name': 'salman', 
    'age': 10,
    'email': 'yahoo.com', 
    'bio': 'CEO of innovative Skills',
    'expertise': 'ML / DL / AI'
}


print(person)

del person

print(person)