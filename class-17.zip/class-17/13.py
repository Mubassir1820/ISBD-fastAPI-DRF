person = {
    'name': 'salman', 
    'age': 10,
    'email': 'yahoo.com', 
    'bio': 'CEO of innovative Skills',
    'expertise': 'ML / DL / AI'
}


person.clear()

print(person)